# -*- coding: utf-8 -*-

from Database import *

class CareProvider:
    def __init__(self, email, password):
        self.email = email
        self.password = password
        sql = f'SELECT PK_user_id, name FROM Users WHERE email = "{self.email}"'
        mycursor.execute(sql)
        
        user_id = mycursor.fetchone(sql)
        self.user_id = user_id[0]
        self.careprovider_name = user_id[1]
        sql = f'SELECT PK_careprovider_id from CareProvider where FK_user_id = "{self.user_id}"'
        mycursor.execute(sql)
        
        careprovider_id = mycursor.fetchone()
        self.careprovider_id = careprovider_id[0]
        sql = f'Select FK_careprovider_id from CareSeeker where FK_careprovider_id = "{self.careprovider_id}"'
        mycursor.execute(sql)
        self.careproviderCount = mycursor.fetchall()
        
    def log_in(self):
        #retrieving passwords for registered mobile no from both table
        sql = f'SELECT password FROM users WHERE email= "{self.email}" '
        mycursor.execute(sql)
        user_info = mycursor.fetchone()     # fetchall provides empty list if record does not exists
        if user_info==[]:
            print(f'{self.email} ot registered. Please try to register first')
            import index      # due to mutual importing we are importing here just before method calling
        elif self.password==user_info[0]:
            print("Logged IN")
            self.dashboard_careprovider()
        else:
            print("Wrong email and password")
            import index

    def dashboard_careprovider(self):
        careseekerCount = len(self.careproviderCount)
        print(f'Currentlty you are taking care of {careseekerCount } Elders\nYou can request for {4-careseekerCount } more elders to take care of.\n1.View list of Available elders to take care of.\n2.Give review and rating for a elder\n3.LogOut')
        choice = int(input())
        if choice==1:
            self.request_careseeker()
        elif choice==2:
            self.review()
        elif choice==3:
            self.log_out()

    # user should be able to see list of available elder and sent them request. NOTE:- 1 user can't sent request to same elder twice
    def request_careseeker(self):
        pass

    # younger can give rating and rating to elders
    def review(self):
        pass

    def log_out(self):
        import index
        