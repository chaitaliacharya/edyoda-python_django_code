# -*- coding: utf-8 -*-
import mysql.connector;
from Database import *

class CareProvider:
    def __init__(self, email, password):
        self.email = email
        self.password = password
        
        mydb = mysql.connector.connect(
        host = "localhost",
        user = "edyoda",
        passwd = "Abcd@1234",
        use_pure = True,
        database = "CAREALL",
        )

        mycursor = mydb.cursor(buffered= True)
        sql = f'SELECT PK_User_id, name FROM Users WHERE email = "{self.email}"'
        mycursor.execute(sql)
        
        user_id = mycursor.fetchone()
        self.user_id = user_id[0]
        self.careprovider_name = user_id[1]
        sql = f'SELECT PK_careprovider_id from CareProvider where FK_user_id = "{self.user_id}"'
        mycursor.execute(sql)
        
        careprovider_id = mycursor.fetchone()
        self.careprovider_id = careprovider_id[0]
        sql = f'Select FK_careprovider_id from CareSeeker where FK_careprovider_id = "{self.careprovider_id}"'
        mycursor.execute(sql)
        self.careproviderCount = mycursor.fetchall()
        
    def log_in(self):
        mydb = mysql.connector.connect(
        host = "localhost",
        user = "edyoda",
        passwd = "Abcd@1234",
        use_pure = True,
        database = "CAREALL",
        )

        mycursor = mydb.cursor(buffered= True)
        #retrieving passwords for registered mobile no from both table
        sql = f'SELECT password FROM users WHERE email= "{self.email}" '
        mycursor.execute(sql)
        user_info = mycursor.fetchone()     # fetchall provides empty list if record does not exists
        if user_info==[]:
            print(f'{self.email} ot registered. Please try to register first')
            #import Index      # due to mutual importing we are importing here just before method calling
        elif self.password==user_info[0]:
            print("Logged IN")
            
            self.dashboard_careprovider()
        else:
            print("Wrong email and password")
            #import Index

    def dashboard_careprovider(self):
        careseekerCount = len(self.careproviderCount)
        print(f'Currentlty you are taking care of {careseekerCount } Elders\nYou can request for {4-careseekerCount } more elders to take care of.\n1.View list of Available elders to take care of.\n2.Give review and rating for a elder\n3.LogOut')
        choice = int(input())
        if choice==1:
            self.request_careseeker()
        elif choice==2:
            self.review()
        elif choice==3:
            self.log_out()


    # user should be able to see list of available elder and sent them request. NOTE:- 1 user can't sent request to same elder twice
    def request_careseeker(self):
        mydb = mysql.connector.connect(
        host = "localhost",
        user = "edyoda",
        passwd = "Abcd@1234",
        use_pure = True,
        database = "CAREALL",
        )

        #Check for available careseekers
        mycursor = mydb.cursor(buffered= True)
        sql = f'Select  PK_careseeker_id, name from Users,CareSeeker where Users.PK_user_id = CareSeeker.FK_user_id and CareSeeker.available = 1'
        mycursor.execute(sql)
        careseeker_info = mycursor.fetchall()
        
        if careseeker_info == []:
            print('Currently all care seekers are unavailable.')
        else:
            #Display available care seeker
            print('The careseekers available are:-')
            careseeker_ids = []
            for careseeker in careseeker_info:
                careseeker_ids.append(careseeker[0])
                print('Careseeker Id: {}   Name: {}'.format(careseeker[0], careseeker[1]))
                
            
            #Taing input from request form care provider 
            print('Enter the id of the care seeker you want to request for:- \n')
            self.careseeker_id_for_request = int(input())
            if self.careseeker_id_for_request  not in careseeker_ids:
                print('You have entered the wrong care seeker id')
            else:
                #Check if already requesedted to the same care seeker
                sql = f'Select FK_careprovider_id, FK_careseeker_id from Request where FK_careprovider_id = {self.careprovider_id} and FK_careseeker_id = {self.careseeker_id_for_request}'
                mycursor.execute(sql)
                request_detail = mycursor.fetchall()
                if request_detail != []:
                    print('You have already requested for this careseeker. Please wait for their approval.')
                else:
                    #Insering the careprovider's request
                    sql = "Insert into Request (FK_careprovider_id, FK_careseeker_id, request_stats) values(%s,%s,%s)"
                    val = (self.careprovider_id, self.careseeker_id_for_request, 0) #Request status is set to 0 considering careprovider request is pending
                    mycursor.execute(sql, val)
                    mydb.commit()
                    print('Your requst is added! Please wait for Care Seeker to approve it.')
            
            

    # younger can give rating and rating to elders
    def review(self):
        mydb = mysql.connector.connect(
        host = "localhost",
        user = "edyoda",
        passwd = "Abcd@1234",
        use_pure = True,
        database = "CAREALL",
        )

        mycursor = mydb.cursor(buffered= True)
         #Get care seeker name
        sql = f'SELECT  name FROM Users, CareProvider WHERE Users.PK_User_id = CareProvider.FK_user_id and CareProvider.PK_careprovider_id = {self.careprovider_id}  '
        mycursor.execute(sql)
        user_name = mycursor.fetchone()
        #Check for care provider entry in care seeker table
        print(self.careprovider_id)
        sql = f'Select PK_careseeker_id from Careseeker where FK_CareProvider_id = {self.careprovider_id}'
        mycursor.execute(sql)
        response = mycursor.fetchone()
        if response != []:
            careseeker_id = response[0]
            sql = f'Select PK_user_id, name from Users, CareSeeker where Users.PK_User_id = CareSeeker.FK_user_id and CareSeeker.PK_careseeker_id = {careseeker_id }'
            mycursor.execute(sql)
            new_response = mycursor.fetchone()
            if new_response !=[]:
                print('Please enter the review for {} \n '.format(new_response[1]))
                review = str(input())
                print('Please enter the rating out of 1 to 10 for {} \n '.format(new_response[1]))
                rating = int(input())
                careseeker_user_id = new_response[0]
                sql = 'Insert into Reviews (FK_user_id,review,rating,review_by) values(%s, %s, %s, %s)'
                val = (careseeker_user_id,review,rating,user_name[0])
                mycursor.execute(sql, val)
                mydb.commit()
                print('Yayy review submitted')
        else:
            print('You dont have any careseekers to give review for')

      
    def log_out(self):
        exit()
        