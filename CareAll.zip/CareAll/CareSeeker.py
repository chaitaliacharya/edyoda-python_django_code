# -*- coding: utf-8 -*-
from Database import *
import mysql.connector;
from User import User
class CareSeeker():
    def __init__(self, email, password):
        self.email = email
        self.password = password
        mydb = mysql.connector.connect(
        host = "localhost",
        user = "edyoda",
        passwd = "Abcd@1234",
        use_pure = True,
        database = "CAREALL",
        )

        mycursor = mydb.cursor(buffered= True)
        sql = f'Select PK_user_id , name from Users where email = "{self.email}"'
        mycursor.execute(sql)
        user_id = mycursor.fetchone()
        self.user_id = user_id[0]
        self.careseeker_name = user_id[1]
        sql = f'Select PK_careseeker_id FROM CareSeeker where FK_user_id = {self.user_id}'
        mycursor.execute(sql)
        careseeker_id = mycursor.fetchone()
        self.careseeker_id = careseeker_id[0]
        
    def log_in(self):
        mydb = mysql.connector.connect(
        host = "localhost",
        user = "edyoda",
        passwd = "Abcd@1234",
        use_pure = True,
        database = "CAREALL",
        )
        mycursor = mydb.cursor(buffered= True)
        #Retriving passwords for registerd mobile no from both table
        sql = f'Select password from Users where email = "{self.email}"'
        mycursor.execute(sql)
        user_info = mycursor.fetchone()
        if user_info == []:
            print(f'{self.email} is not registered. Please try to register first.')
            import Index
        elif self.password == user_info[0]:
            print("Logged In")
            self.dashboard_careseeker()
        else:
            print('Wrong email and password')
            
    def dashboard_careseeker(self):
        mydb = mysql.connector.connect(
        host = "localhost",
        user = "edyoda",
        passwd = "Abcd@1234",
        use_pure = True,
        database = "CAREALL",
        )

        mycursor = mydb.cursor(buffered= True)
        sql = f'SELECT available from CareSeeker where PK_careseeker_id = {self.careseeker_id}'
        mycursor.execute(sql)
        user_info = mycursor.fetchone()
        if user_info[0] == 1:
            print('You are currently Available to take care of.\n1.Make Unavailable\n2.Fund\n3.Request\n4.Take Care Name\n5.Give review and rating for a younger\n6.LogOut')
            choice = int(input())
            if choice == 1:
                self.change_status()
            elif choice == 2:
                self.allocate_fund()
            elif choice == 3:
                self.show_request()
            elif choice == 4:
                self.take_care_name()
            elif choice == 5:
                self.review()
            elif choice == 6:
                self.log_out()
            
        else:
            print('You are currently unavailable to take care of.\n1.Make Available\n2.Log Out')
            choice = int(input())
            if choice == 1:
                self.change_status()
                self.dashboard_careseeker()
            elif choice == 2:
                self.log_out()
                
         # elder should be able to allocate fund
    def allocate_fund(self):
        mydb = mysql.connector.connect(
        host = "localhost",
        user = "edyoda",
        passwd = "Abcd@1234",
        use_pure = True,
        database = "CAREALL",
        )
        mycursor = mydb.cursor(buffered= True)
        print('Enter the fund amount you want to alloacate:\n')
        fund = int(input())
        sql = 'Update CareSeeker set fund = %s where PK_careseeker_id =%s'
        val = (fund,self.careseeker_id)
        mycursor.execute(sql, val)
        mydb.commit()
        print('Fund allocated successfully!')
        
    # elder can change their status from available to unavailable and vice-versa
    def change_status(self):
        mydb = mysql.connector.connect(
        host = "localhost",
        user = "edyoda",
        passwd = "Abcd@1234",
        use_pure = True,
        database = "CAREALL",
        )
        mycursor = mydb.cursor(buffered= True)
    
        print('Do you want to change availability, Press Y from being avalable and Press N for being unavailable:-\n')
        answer = str(input())
        if answer == 'Y':
            sql = 'Update CareSeeker set available = %s where  PK_CareSeeker_id =%s'
            val = (1,self.careseeker_id)
            mycursor.execute(sql,val)
            mydb.commit()
            print('You are now available for seeking care')
                    
        elif answer == 'N':
            sql = 'Update CareSeeker set available = %s where  PK_CareSeeker_id =%s'
            val = (0,self.careseeker_id)
            mycursor.execute(sql,val)
            mydb.commit()
            print('You are now unavailable for seeking care')
        else:
            print('Incorrect input provided')
        
                
    

    # elder can see requests and accept whome they trus only 1 request can be accepted by elder      
    def show_request(self):
        mydb = mysql.connector.connect(
        host = "localhost",
        user = "edyoda",
        passwd = "Abcd@1234",
        use_pure = True,
        database = "CAREALL",
        )

        mycursor = mydb.cursor(buffered= True)
        sql = f"Select name, email, mobile, rating, CareProvider.PK_careprovider_id from users, CareProvider where PK_user_id = CareProvider.FK_User_id  and PK_user_id in(select FK_user_id from CareProvider,Request where CareProvider.PK_careprovider_id = Request.FK_careprovider_id and Request.FK_careseeker_id in (select FK_careseeker_id from Request, CareSeeker where CareSeeker.PK_careseeker_id = {self.careseeker_id} and Request.FK_Careseeker_id= CareSeeker.PK_careseeker_id))"
        mycursor.execute(sql)
        self.request_details = mycursor.fetchall()
        print('Below are the requests:\n')
        careprovider_name = []
        careprovider_id= []
        for request in  self.request_details:
            careprovider_name.append(request[0])
            careprovider_id.append(request[4])
            print('Care Provider Name: ', request[0])
            print('Care Provider Email: ', request[1])
            print('Care Provider Mobile No: ', request[2])
            print('Care Provider Rating: ', request[3])
            print('Id',request[4] )
            print('****************************************************')
      
        print("Do you want accept request for a Care Provider: Yes or No. Press Y for Yes and N for No\n")
        response = str(input())
        if response == 'Y':
            print('Enter the ID of the Care Provider:\n')
            cp_id= int(input())
            if cp_id  not in  careprovider_id:
                print('You have enetered the wrong id ')
            else:
                sql = f'Update Request set request_stats = 1 where FK_careprovider_id = %s and FK_careseeker_id = %s'
                val = (cp_id, self.careseeker_id)
                mycursor.execute(sql,val)
                mydb.commit()
                print('Yayy !You have accepted the request')
                
                #Updating the careseeker table with the Id of the careprovider whose equest was accepted
                sql = f'Update CareSeeker set FK_careprovider_id = %s where PK_careseeker_id = %s'
                val = (cp_id, self.careseeker_id)
                mycursor.execute(sql,val)
                mydb.commit()
        elif response == 'N':
            exit()
        else:
            print('Incorrect input provided')

    # elder can see name of younger who is taking care of them
    def take_care_name(self):
        mydb = mysql.connector.connect(
        host = "localhost",
        user = "edyoda",
        passwd = "Abcd@1234",
        use_pure = True,
        database = "CAREALL",
        )

        mycursor = mydb.cursor(buffered= True)
        sql = f'select name, rating from Users, CareProvider where Users.PK_User_id = CareProvider.FK_user_id and PK_User_Id in (select FK_user_id from CareProvider where PK_careprovider_id in (select FK_careprovider_id from Request where request_stats = 1 and FK_careseeker_id = {self.careseeker_id})); '
        mycursor.execute(sql)
        care_name = mycursor.fetchall()
        for careprovider in care_name:
            print('Care Provider name {}  Rating {} '.format(careprovider[0], careprovider[1]))


    # elder can give review and rating to youngers
    def review(self):
        mydb = mysql.connector.connect(
        host = "localhost",
        user = "edyoda",
        passwd = "Abcd@1234",
        use_pure = True,
        database = "CAREALL",
        )

        mycursor = mydb.cursor(buffered= True)
         #Get care seeker name
        sql = f'SELECT  name FROM Users, CareSeeker WHERE Users.PK_User_id = CareSeeker.FK_user_id and CareSeeker.PK_careseeker_id = {self.careseeker_id}  '
        mycursor.execute(sql)
        user_name = mycursor.fetchone()
        #Check for care provider for giving review for care provider
        sql = f'Select FK_careprovider_id from Careseeker where PK_CareSeeker_id = {self.careseeker_id}'
        mycursor.execute(sql)
        response = mycursor.fetchone()
        if response != []:
            careprovider_id = response[0]
            sql = f'Select PK_user_id, name from Users, CareProvider where Users.PK_User_id = CareProvider.FK_user_id and CareProvider.PK_careprovider_id = {careprovider_id }'
            mycursor.execute(sql)
            new_response = mycursor.fetchone()
            if new_response !=[]:
                print('Please enter the review for {} \n '.format(new_response[1]))
                review = str(input())
                print('Please enter the rating out of 1 to 10 for {} \n '.format(new_response[1]))
                rating = int(input())
                careprovider_user_id = new_response[0]
                sql = 'Insert into Reviews (FK_user_id,review,rating,review_by) values(%s, %s, %s, %s)'
                val = (careprovider_user_id,review,rating,user_name[0])
                mycursor.execute(sql, val)
                mydb.commit()
                print('Yayy review submitted')
                
                
                sql = f'Update Careprovider set rating = %s where PK_CareProvider_id = %s'
                val = (rating,careprovider_id )
                mycursor.execute(sql,val)
                mydb.commit()
        else:
             print('You cannot give review or rating for a careprovider as of now')

    def log_out(self):
        exit()
        
        
        
        
        
        