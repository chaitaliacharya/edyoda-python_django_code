# -*- coding: utf-8 -*-

import mysql.connector;

#Connecting mysql
mydb = mysql.connector(
        host = "",
        user = "",
        passwd = "",
        use_pure = "True")

cursor = mydb.cursor()

#Creating datavase if does not exist

cursor.execute("Create database if not exists CAREALL")

#Getting database
mydb = mysql.connector(
        host = "",
        user = "",
        passwd ="",
        use_pure = "",
        database = "CAREALL")

mycursor = mydb.cursor()

#Creating table for User
mycursor.execute("CREATE TABLE IF NOT EXISTS Users (PK_user_id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), email VARCHAR(255) UNIQUE, password VARCHAR(255), mobile VARCHAR(10) UNIQUE)")

#Creating table for careprovider and careseeker
mycursor.execute("CREATE TABLE IF NOT EXISTS CareProvider (PK_careprovider_id INT AUTO_INCREMENT PRIMARY KEY, FK_user_id INTEGER references Users(PK_user_id), rating FLOAT)")
mycursor.execute("CREATE TABLE IF NOT EXISTS CareSeeker (PK_careseeker_id INT AUTO_INCREMENT PRIMARY KEY, FK_user_id INTEGER references Users(PK_user_id), FK_careprovider_id INTEGER refrences CareProvider(PK_careprovider_id), available BOOLEAN Default TRUE, fund INTEGER, rating FLOAT)")


#Create request table 
mycursor.execute("CREATE TABLE IF NOT EXISTS Request(PK_request_id INT AUTO_INCREMENT PRIMARY KEY, FK_careprovider_id INTEGER references CareProvider(PK_careproivder_id), FK_careseeker_id INTEGER references CareSeeker(PK_careseeker_id), request_stats BOOLEAN Default False)")

#Create reviews table
mycursor.execute("CREATE TABLE IF NOT EXISTS Reviews(PK_review_id INT AUTO_INCREMENT PRIMARY KEY, FK_user_id INTEGER references Users(PK_user_id),review TEXT, rating INTEGER, review_by VARCHAR(255))")
