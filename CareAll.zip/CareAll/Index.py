# -*- coding: utf-8 -*-
from Database import *
from CareProvider import CareProvider
from CareSeeker import CareSeeker

def welcome():
      print("Please select\n1. Login as Elder \n2. Login as Younger\n3. Register\n4. View all youngers who are taking care\n5. View who is taking care of older couple\n6. Exit")
      task = int(input())
      if task == 1:
          mobile = input("Welcome CareSeeker \n Enter your email")
          password = input("Enter Your Password:")
          user = CareSeeker(mobile, password)
          user.log_in()
      elif  task == 2:
          mobile = input("Welcome CareProvider \n Enter your email")
          password = input("Enter Your Password:")
          user = CareProvider(mobile, password)
          user.log_in()
      elif task == 3:
          name = input("Register yourself \n Enter your Full Name")
          email = input("Enter your email: ")
          mobile = input("Enter your mobile number")
          password = input("Enter your password: ")
          
          wh
          
