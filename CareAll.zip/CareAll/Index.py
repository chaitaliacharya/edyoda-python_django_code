# -*- coding: utf-8 -*-
from Database import *
import mysql.connector;
from CareProvider import CareProvider
from CareSeeker import CareSeeker
from User import User
import sys
def welcome():
      print("Please select\n1. Login as Elder \n2. Login as Younger\n3. Register\n4. View all youngers who are taking care\n5. View who is taking care of older couple\n6. Exit")
      task = int(input())
      if task == 1:
          mobile = input("Welcome CareSeeker \n Enter your email: ")
          password = input("Enter Your Password:")
          user = CareSeeker(mobile, password)
          user.log_in()
      elif  task == 2:
          email = input("Welcome CareProvider \n Enter your email: ")
          password = input("Enter Your Password:")
          user = CareProvider(email, password)
          user.log_in()
      elif task == 3:
          name = input("Register yourself \n Enter your Full Name: ")
          email = input("Enter your email: ")
          mobile = input("Enter your mobile number: ")
          password = input("Enter your password: ")
          
          while True:
                role = int(input("select your role:\n1. CareSeeker \n2. CareProvider\n"))
                try:
                    if role==1:
                        role="CareSeeker"
                        break
                    elif role==2:
                        role="CareProvider"
                        break
                except:
                    print(f'option not Valid! Please try again')
    
          user_signup = User(name, email, password, mobile, role)
          user_signup.user_registration()
      
      # All care providers who are taking care
      elif task==4:
        mydb = mysql.connector.connect(
        host = "localhost",
        user = "edyoda",
        passwd = "Abcd@1234",
        use_pure = True,
        database = 'CAREALL',
        )

        mycursor = mydb.cursor(buffered= True)
        
        sql = 'select name from users, CareProvider where Users.PK_User_ID = CareProvider.FK_user_id and CareProvider.PK_careprovider_id in (select FK_careprovider_id from careseeker where FK_careprovider_id != "NULL") '
        mycursor.execute(sql)
        result = mycursor.fetchall()
        print('The care providers taking care are:-')
        for name in result:
            print(name[0])

    # enter elder's mobile number of email boh are unique here and display their take care name
      elif task==5:
        mydb = mysql.connector.connect(
        host = "localhost",
        user = "edyoda",
        passwd = "Abcd@1234",
        use_pure = True,
        database = 'CAREALL',
        )

        mycursor = mydb.cursor(buffered= True)
        print('Enter mobile number of Care Seeker:-\n')
        mobile = input()
        print('Enter email of Care Seeker:-\n')
        email = input()
         
        #Get id and name of careseeker
        sql = f'select PK_User_id, name from Users where email = "{email}"'
        mycursor.execute(sql)
        result = mycursor.fetchone()
        
        if result != []:
            sql = f'select name, rating from Users, CareProvider where PK_User_id= CareProvider.FK_User_id and PK_CareProvider_id = (select FK_careprovider_id from CareSeeker where FK_user_id = {result[0]}) '
            mycursor.execute(sql)
            care_name = mycursor.fetchall()
            print('Below is the name of Care Provider and Rating for the Care Seeker',result[1])
            for careprovider in care_name:
                print('Care Provider name {}  Rating {} '.format(careprovider[0], careprovider[1]))
        else:
            print('Incorrect inut provided ')
          

      elif task==6:
          sys.exit(0)
          
