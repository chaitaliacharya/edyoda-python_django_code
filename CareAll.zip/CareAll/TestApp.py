# -*- coding: utf-8 -*-

import Index

if __name__ == "__main__":
    print('Start Care All')
    Index.welcome()
    