# -*- coding: utf-8 -*-
from Database import *
class User:
    def __init__(self, name, email, password, mobile, role):
        self.name = name
        self.email = email
        self.password = password
        self.mobile = mobile
        self.role = role
        
    def get_user_id(self):
        sql = f'SELECT PK_user_id FROM Users where email = "{self.email}" '
        mycursor.execute(sql)
        user_id = mycursor.fetchone()
        return user_id
    
    def user_registration(self):
        #retriving all registered email from user table
        user_id = self.get_user_id()
        
        if user_id is None:
            sql = f"Insert into Users (name, email, password, mobile) values (%s, %s, %s, %s)"
            val = (self.name, self.email, self.password, self.mobile)
            mycursor.execute(sql, val)
            mydb.commit()
        else: 
            print(f'Account already created for {self.email}. Please try to login using mobile number and password. \n Want to reset password? \n1. Yes \n2. No')
            reset_pass = int(input)
            #Reset password function
            if reset_pass == 1:
                new_pass = input('Enter your new password: ')
                sql = "Update Users set password = %s where email = %s"
                val = (new_pass, self.email)
                mycursor.execute(sql,val)
                mydb.commit("Password updated successfully!")
            else:
                import Index
                
        if self.role == "CareProvider":
            user_id = self.get_user_id()
            sql = "Insert into CareProvider (FK_user_id) VALUES ('%s')"
            val = user_id
            mycursor.execute(sql, val)
            mydb.commit()
        elif self.role == "CareSeeker":
            user_id = self.get_user_id()
            sql = "INSERT INTO CareSeeker (FK_user_id) VALUES ('%s')"
            val = user_id
            mycursor.execute(sql, val)
            mydb.commit()
            import Index
    