# -*- coding: utf-8 -*-


class Billing:
    
    def calculateFine(issue_days, is_extended):
        fine_per_day = 50
        fine_amount = 0
        if issue_days <= 10:
            fine_amount = 0
        elif issue_days in range(10,16) and is_extended == False:
            days_for_fine = issue_days - 10 #As 10 is the number of days allowed without extension
            fine_amount = days_for_fine * fine_per_day
        else:
            days_for_fine = issue_days - 15 #As 15 is the number of days allowed withextension
            fine_amount = days_for_fine * fine_per_day
        return fine_amount
        
