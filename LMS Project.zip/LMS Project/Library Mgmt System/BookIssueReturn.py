# -*- coding: utf-8 -*-
from Catalog import Catalog
from Billing import Billing
class BookIssueReturn:
    def issueBook(book,issuer_id,issuer_name,issue_days):
        catalog = Catalog()
        catalog.setIssuerDetailsForBookItem(book,issuer_id, issuer_name,issue_days)
        Catalog.book_issue_count +=1
        
    def returnBook(book, issuer_id):
        catalog = Catalog()
        catalog.retunBookUpdateCatalog(book,issuer_id)
        Catalog.book_issue_count -=1
        
    def extendBookIssueDays(book,issuer_id):
        catalog = Catalog()
        issue_days = 5
        extended = catalog.extendBookIssueDays(book, issuer_id, issue_days)
        return extended
        
    def getIssueDaysAndExtendedForaParticularBook(book,issuer_id):
        catalog = Catalog()
        issue_days_ext = catalog.getIssueDaysAndExtendedForaParticularBook(book, issuer_id)
        return  issue_days_ext
        
        
    def getFineAmount(issue_days,issuer_id):
        fine_amount = Billing.calculateFine(issue_days,issuer_id)
        return fine_amount
        
     
      

