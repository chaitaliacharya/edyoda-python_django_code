# -*- coding: utf-8 -*-
class BookItem:
    def __init__(self,book,isbn,rack,issuer_id = 0,issuer_name = '',issue_days=0,is_extended = False):
        self.book = book
        self.isbn = isbn
        self.rack = rack
        self.issuer_id = issuer_id
        self.issuer_name = issuer_name
        self.issue_days = issue_days
        self.is_extended = is_extended
        
        
   
    def setBookIssuerDetails(self,n_issuer_id,n_issuer_name,n_issue_days):
        self.issuer_id = n_issuer_id
        self.issuer_name = n_issuer_name
        self.issue_days = n_issue_days
       
        
    def increaseIssueDays(self,issue_days,is_extended):
        self.issue_days = issue_days
        self.is_extended = is_extended
        
        
