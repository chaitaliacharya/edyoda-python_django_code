# -*- coding: utf-8 -*-
from Book import Book

class Catalog:
    books = []
    different_book_count = 0
    book_issue_count = 0
    

    @classmethod
    def checkIfBookExistsByName(self,name):
         book_by_name_exist = [book for book in self.books if book.name == name]
         if  book_by_name_exist:
             return book_by_name_exist[0]
         else:
             return False
    @classmethod
    def checkIfBookExistsByAuthor(self,author):
         book_by_author_exist = [book for book in self.books if book.author == author]
         if book_by_author_exist:
             return book_by_author_exist[0]
         else:
             return False
         
    @classmethod
    def checkIfBookIssuedByMember(self,bookname,issuer_id):
        book = Catalog.checkIfBookExistsByName(bookname)
        if book:
            is_issued = book.checkIfBookIssuedByMember(issuer_id)
            return is_issued
        else:
            return False
        
        
      
      #Only available to admin
    def addBook(self,name,author,publish_date,pages):
        b = Book(name,author,publish_date,pages)
        Catalog.different_book_count +=1
        Catalog.books.append(b)
        return b
    
    #Only available to admin
    def addBookItem(self,book,isbn,rack):
        book.addBookItem(isbn, rack)
        
            
    def searchByName(self,name):
        book_name_exist = Catalog.checkIfBookExistsByName(name)
        if book_name_exist:
            print('The book {} is present in library'.format(book_name_exist.name))
            print('Author',book_name_exist.author)
            print('Number of copies of this book in library:-',book_name_exist.total_count)
        else:
            print('This book is not present in the library')
            
    def searchByAuthor(self,author):
       book_by_author_exist = Catalog.checkIfBookExistsByAuthor(author)
       if book_by_author_exist:
           print('Book by author {} is present in library '.format(book_by_author_exist.author))
           print('Book Name',book_by_author_exist.name)
           print('Number of copies of this book in library:-',book_by_author_exist.total_count)
       else:
           print('This book is not present in the library')
    
        
    def displayAllBooks(self):
        print ('Different Book Count',Catalog.different_book_count)
        print('The number of books issued are:', Catalog.book_issue_count)
        c = 0
        for book in Catalog.books:
            c += book.total_count
            book.printBook()
        print ('Total Book Count',c)
        
    def setIssuerDetailsForBookItem(self,book,issuer_id, issuer_name,issue_days):
        book.setBookIssuerDetails(issuer_id, issuer_name,issue_days)
        

        
    def displayIssuerDetails(self):
        print('The issued books are:-')
        for book in Catalog.books:
            Catalog.book_issue_count +=1
            book.printBookIssuerDetails()
       
            
    def retunBookUpdateCatalog(self,book,issuer_id):
        book.retunBookUpdateBookItem(issuer_id)
        
    def increaseIssueDays(self, member_id, book,issue_days):
        book_name_exist = Catalog.checkIfBookExistsByName(book)
        if book_name_exist:
            book_name_exist.increaseIssueDays(member_id,issue_days)
    
    def extendBookIssueDays(self,book, issuer_id, issue_days):
        extended = book.extendBookIssueDays(issuer_id, issue_days)
        return extended
        
    def viewIssuedBooks(self,issuer_id):
        is_any_book_issued = []
        for books in Catalog.books:
            is_issued = books.checkIfBookIssuedByMember(issuer_id)
            is_any_book_issued.append(is_issued)
            
        if True in is_any_book_issued:
            for books in Catalog.books:
                books.viewIssuedBooks(issuer_id)
        else:
            print('No Books Issued')
            
            
    def getIssueDaysAndExtendedForaParticularBook(self,book,issuer_id):
            issue_days_ext = book.getIssueDayAndExtendedsForaParticularBook(issuer_id)
            return issue_days_ext 
            
                
                
                
                
                
                
