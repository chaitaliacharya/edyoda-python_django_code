# -*- coding: utf-8 -*-
from Catalog import Catalog
from BookIssueReturn import BookIssueReturn

class User:
    def __init__(self, name, location, age, aadhar_id):
        self.name = name
        self.location = location
        self.age = age
        self.aadhar_id = aadhar_id
        

class Member(User):
    def __init__(self,name, location, age, aadhar_id,student_id,paid_fine = 0):
        super().__init__(name, location, age, aadhar_id )
        self.student_id = student_id
        self.paid_fine = paid_fine
        
    def __repr__(self):
        return self.name + ' ' + self.location + ' ' + self.student_id + ' ' + self.paid_fine
    
    #assume name is unique
    def issueBook(self,bookname,days=10):
        book_exist = Catalog.checkIfBookExistsByName(bookname)
        if book_exist:
            BookIssueReturn.issueBook(book_exist,self.student_id,self.name,days)
            print('Book Issued Successfully!')
            Catalog.viewIssuedBooks(self,self.student_id)
        else:
            print('This book does not exist in the library')
            
            
    #assume name is unique
    def returnBook(self,bookname):
        book_exist = Catalog.checkIfBookExistsByName(bookname)
        book_issued_by_user = Catalog.checkIfBookIssuedByMember(bookname, self.student_id)
        
        if book_exist and  book_issued_by_user:
            extended = Member.extendBookIssueDays(book_exist , self.student_id, bookname)
            if extended == 'Incorrect':
                print('Incorrect reponse for extending book days')
    
            elif extended:
                print('Book extended successfully!')
                Catalog.viewIssuedBooks(self,self.student_id)
                
            else:
                issue_days_ext = BookIssueReturn.getIssueDaysAndExtendedForaParticularBook(book_exist,self.student_id)
                fine = BookIssueReturn.getFineAmount(issue_days_ext[0],issue_days_ext[-1])
                if fine == 0 :
                        print('Hey no fines for you! Thats Awesome!')
                        BookIssueReturn.returnBook(book_exist,self.student_id)
                        print('Book is returned to the library')
                        Catalog.viewIssuedBooks(self,self.student_id)
                else:
                    if self.paid_fine == 1:
                        print('Hey no fines for you! Thats Awesome!')
                        BookIssueReturn.returnBook(book_exist,self.student_id)
                        print('Book is returned to the library')
                        Catalog.viewIssuedBooks(self,self.student_id)
                    else:
                        print('Uh oh you were late on returning your book and your fine amount is:', fine)
                        print('Please pay your fine and then return your book.')
                    
                
        else:
            if not book_exist:
                print('This book {} is not present in library'.format(bookname))
            else:
                print('This book {} is not issued by you'.format(bookname))
                  
    def extendBookIssueDays(book, student_id,bookname):
        print('Do you want to extend the issue days for the Book {} '.format(bookname))
        response = str(input("Press Y for Yes or N for No:- "))
        print(response)
        if response == 'Y' :
            extended = BookIssueReturn.extendBookIssueDays(book,student_id)
            return extended
        elif response == 'N':
            return False
        else:
            return 'Incorrect'
        
    def viewIssuedBooks(self):
        Catalog.viewIssuedBooks(self,self.student_id)
        
    def payFine(self):
        self.paid_fine = 1
        
        
  
       

        
class Librarian(User):
    def __init__(self,name, location, age, aadhar_id,emp_id):
        super().__init__(name, location, age, aadhar_id)
        self.emp_id = emp_id
        
    def __repr__(self):
        return self.name + self.location + self.emp_id
    
    def addBook(self,name,author,publish_date,pages):
        catalog = Catalog()
        b = catalog.addBook(name,author,publish_date,pages)
        return b
    
    def addBookItem(self,book,isbn,rack):
        Catalog.addBookItem(book,isbn,rack)
    
    
    def removeBook(self,name):
        #Check if the book by the given name exists
        book_name_exist = Catalog.checkIfBookExistsByName(name)
        if book_name_exist:
           Catalog.books.remove(book_name_exist)
           Catalog.different_book_count -=1
        else:
            print('This book is not present in the library')
    
    
        