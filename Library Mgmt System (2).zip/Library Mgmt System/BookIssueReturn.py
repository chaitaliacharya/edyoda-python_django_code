# -*- coding: utf-8 -*-
from Catalog import Catalog
class BookIssueReturn:
    def issueBook(self, username,user_id,bookname,days = 10):
        print(user_id,username,bookname,days)
        for book in Catalog.books:
            if book.name == bookname:
                book.setBookIssuerDetails(user_id,username,days)
                book.printBook()
      

