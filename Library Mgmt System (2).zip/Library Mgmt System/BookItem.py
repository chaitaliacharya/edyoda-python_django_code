# -*- coding: utf-8 -*-
class BookItem:
    def __init__(self,book,isbn,rack):
        self.book = book
        self.isbn = isbn
        self.rack = rack
       
        
    def setBookIssuerDetails(self,book,issuer_id,issuer_name,issue_days = 10):
        print('dsdsd')
        self.book = book
        self.issuer_id = issuer_id
        self.issuer_name = issuer_name
        self.issue_days = issue_days

  
        
        
