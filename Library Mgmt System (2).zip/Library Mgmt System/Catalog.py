# -*- coding: utf-8 -*-
from Book import Book
#First Book is file & second is Class

class Catalog:
    books = []
    diff_count = 0
    def __init__(self):
        self.different_book_count = 0
        #self.books = []
        
    #Only available to admin
    def addBook(self,name,author,publish_date,pages):
        b = Book(name,author,publish_date,pages)
        #self.different_book_count += 1
        Catalog.diff_count +=1
        Catalog.books.append(b)
        return b
    
    #Only available to admin
    def addBookItem(self,book,isbn,rack):
        book.addBookItem(isbn, rack)
        
    def setBookItem(self,book,issuer_id,issuer_name,issue_days):
        book.setBookItem(issuer_id,issuer_name,issue_days)
        
    def searchByName(self,name):
        #Check if the book by the given name exists, if it does collect in a list
        book_name_exist = [book for book in self.books if book.name == name]
        if book_name_exist:
            print('The book {} is present in library'.format(book_name_exist[-1].name))
            print('Author',book_name_exist[-1].author)
            print('Number of copies of this book in library:-',book_name_exist[-1].total_count)
        else:
            print('This book is not present in the library')

        
    
    def searchByAuthor(self,author):
         #Check if the book by the given author exists, if it does collect in a list
        book_author_exist = [book for book in self.books if book.author == author]
        if book_author_exist:
            print('Book by author {} is present in library '.format(book_author_exist[-1].author))
            print('Book Name',book_author_exist[-1].name)
            print('Number of copies of this book in library:-',book_author_exist[-1].total_count)
        else:
            print('This book is not present in the library')
    
        
    def displayAllBooks(self):
        print ('Different Book Count',Catalog.diff_count)
        c = 0
        for book in Catalog.books:
            c += book.total_count
            book.printBook()
        print ('Total Book Count',c)
        
        
    def displayAllIssuerDetails(self):
        for book in Catalog.books:
            book.printBookIssuerDetails()
