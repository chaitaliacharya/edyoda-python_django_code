# -*- coding: utf-8 -*-
from BookItem import BookItem
class Book:
    def __init__(self,name,author,publish_date,pages):
        self.name = name
        self.author = author
        self.publish_date = publish_date
        self.pages = pages
        self.total_count = 0
        self.book_item = []
        self.book_issuer_details = []
        
        
    def addBookItem(self,isbn,rack):
        b = BookItem(self,isbn,rack,issuer_id = 0 ,issuer_name = '',issue_days = 0)
        self.book_item.append(b)
        self.total_count +=1
    
    def setBookIssuerDetails(self,issuer_id, issuer_name,issue_days):
       book_issue = [book for book in self.book_item if book.issuer_id == 0]
       if book_issue:
           book_issue[0].setBookIssuerDetails(issuer_id, issuer_name,issue_days)
       else:
           print('All copies of this book are issued')
           
    def retunBookUpdateBookItem(self,issuer_id):
        book_issue = [book for book in self.book_item if book.issuer_id == issuer_id]
        if book_issue:
            issue_days = 0
            issuer_name = ''
            issuer_id = 0
            book_issue[0].setBookIssuerDetails(issuer_id, issuer_name,issue_days)
           
    def checkBookItemIssued(self,issuer_id):
        book_issue = [book for book in self.book_item if book.issuer_id == issuer_id]
        if book_issue:
            return True
        else:
            return False
            
                
    def printBook(self):
        print (self.name,self.author)
        for book_item in self.book_item:
            if book_item.issuer_name == '':
                 print ('Book Id-{} Issued by - None'.format(book_item.isbn))
            else:
                print ('Book Id-{} Issued by - {}'.format(book_item.isbn, book_item.issuer_name))

           
    def printBookIssuerDetails(self):
        for book in self.book_item:
            if book.issuer_id != 0:
                print('Book Name: {}  | Issuer Name - {} | Days Issued = {}'.format(self.name,book.issuer_name, book.issue_days))
            
  
                
                
                
                
                
        