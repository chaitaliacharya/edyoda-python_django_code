# -*- coding: utf-8 -*-
from Catalog import Catalog
class BookIssueReturn:
    def issueBook(book,issuer_id,issuer_name,issue_days):
        catalog = Catalog()
        catalog.setIssuerDetailsForBookItem(book,issuer_id, issuer_name,issue_days)
        
    def returnBook(book, issuer_id):
        catalog = Catalog()
        catalog.retunBookUpdateCatalog(book,issuer_id)
        
     
      

