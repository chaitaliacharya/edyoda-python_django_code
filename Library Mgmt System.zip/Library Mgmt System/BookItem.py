# -*- coding: utf-8 -*-
class BookItem:
    bookItem = []
    def __init__(self,book,isbn,rack,issuer_id,issuer_name,issue_days):
        self.book = book
        self.isbn = isbn
        self.rack = rack
        self.issuer_id = issuer_id
        self.issuer_name = issuer_name
        self.issue_days = issue_days
        BookItem.bookItem.append(self)
        
       
   
    def setBookIssuerDetails(self,n_issuer_id,n_issuer_name,n_issue_days):
        self.issuer_id = n_issuer_id
        self.issuer_name = n_issuer_name
        self.issue_days = n_issue_days
       
        
  
        
        
