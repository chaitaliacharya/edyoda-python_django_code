# -*- coding: utf-8 -*-
from BookItem import BookItem
class Book:
    def __init__(self,name,author,publish_date,pages):
        self.name = name
        self.author = author
        self.publish_date = publish_date
        self.pages = pages
        self.total_count = 0
        self.book_item = []
        self.book_issuer_details = []
        
        
    def addBookItem(self,isbn,rack):
        b = BookItem(self,isbn,rack,issuer_id = 0 ,issuer_name = '',issue_days = 0)
        self.book_item.append(b)
        self.total_count +=1
    
    def setBookIssuerDetails(self,issuer_id, issuer_name,issue_days):
        book = [books for books in BookItem.bookItem]
        b = book.setBookIssuerDetails(self,issuer_id, issuer_name,issue_days)
        
        




            

           
         
         
         
             
     
        
      
       
        


    def printBook(self):
        print (self.name,self.author)
        for book_item in self.book_item:
            print (book_item.isbn, book_item.issuer_id)

    def printBookIssuerDetails(self):
        for book_item in self.book_issuer_details:
            print (book_item.issuer_id, book_item.issuer_name)
        
        