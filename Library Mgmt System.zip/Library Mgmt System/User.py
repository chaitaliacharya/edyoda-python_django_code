# -*- coding: utf-8 -*-
from Catalog import Catalog
from Book import Book
class User:
    def __init__(self, name, location, age, aadhar_id):
        self.name = name
        self.location = location
        self.age = age
        self.aadhar_id = aadhar_id
        

class Member(User):
    def __init__(self,name, location, age, aadhar_id,student_id):
        super().__init__(name, location, age, aadhar_id)
        self.student_id = student_id
        
    def __repr__(self):
        return self.name + ' ' + self.location + ' ' + self.student_id
    
    #assume name is unique
    def issueBook(self,name,days=10):
        pass
    
    #assume name is unique
    def returnBook(self,name):
        pass
        
        
class Librarian(User):
    def __init__(self,name, location, age, aadhar_id,emp_id):
        super().__init__(name, location, age, aadhar_id)
        self.emp_id = emp_id
        
    def __repr__(self):
        return self.name + self.location + self.emp_id
    
    def addBook(self,name,author,publish_date,pages):
        catalog = Catalog()
        b = catalog.addBook(name,author,publish_date,pages)
        return b
    
    def addBookItem(self,book,isbn,rack):
        Catalog.addBookItem(book,isbn,rack)
    
    
    def removeBook(self,name):
        #Check if the book by the given name exists, if it does collect in a list
        book_name_exist = [book for book in Catalog.books if book.name == name]
        if book_name_exist:
           Catalog.books.remove(book_name_exist[-1])
           Catalog.diff_count -=1
        else:
            print('This book is not present in the library')
    
    
        